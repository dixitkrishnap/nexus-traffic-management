"""
main.py — NEXUS Automated Traffic Management System
Run: uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from core.config import settings
from db.database import init_db
from services.iot_sensor import sensor_engine_loop, signal_engine_loop
from api.routes import traffic, signals, ai_chat, emergency, alerts, analytics


@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"\n{'='*55}")
    print(f"  NEXUS Automated Traffic Management System v{settings.VERSION}")
    print(f"  LLM Model   : {settings.LLM_MODEL}")
    print(f"  API Key set : {'YES' if settings.ANTHROPIC_API_KEY else 'NO (demo mode)'}")
    print(f"{'='*55}\n")
    await init_db()
    sensor_task = asyncio.create_task(sensor_engine_loop())
    signal_task = asyncio.create_task(signal_engine_loop())
    print("All engines running. API ready.\n")
    yield
    sensor_task.cancel()
    signal_task.cancel()
    print("NEXUS shutting down.")


app = FastAPI(
    title="NEXUS — Automated Traffic Management System",
    description="AI + IoT Traffic Management for Chennai Metro. 48 IoT sensors, 12 adaptive signal controllers, Claude LLM.",
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.mount("/static", StaticFiles(directory="."), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(traffic.router,   prefix="/api/traffic",   tags=["Traffic & Zones"])
app.include_router(signals.router,   prefix="/api/signals",   tags=["Signal Control"])
app.include_router(ai_chat.router,   prefix="/api/ai",        tags=["AI / LLM"])
app.include_router(emergency.router, prefix="/api/emergency", tags=["Emergency"])
app.include_router(alerts.router,    prefix="/api/alerts",    tags=["Alerts"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])


@app.get("/", response_class=RedirectResponse)
async def root():
    # Redirect root to the main dashboard
    return RedirectResponse(url="/static/index.html")


@app.get("/health", tags=["Health"])
async def health():
    from services.state_store import store
    m = store.get_metrics()
    return {
        "status": "healthy",
        "version": settings.VERSION,
        "llm": "live" if settings.ANTHROPIC_API_KEY else "demo",
        "running": store.running,
        "metrics": m,
        "services": {
            "sensor_engine": "running",
            "signal_engine": "running",
            "llm_engine": "live" if settings.ANTHROPIC_API_KEY else "demo",
            "database": "sqlite",
            "websocket": "ready",
        },
    }
